<?php

if (isset($_SERVER['bundle.dummy.routes']))
{
	$_SERVER['bundle.dummy.routes']++;
}