<?php

return array(
	'bootstrapper' => array('auto' => true)
);