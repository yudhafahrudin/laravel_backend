$("#new_critt").charCounter(320, {
	container: "<h6></h6>",
	classname: "pull-right",
	format: "%1 characters remaining",
	pulse: true
});