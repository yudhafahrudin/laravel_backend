<?php

return array(

	'debug' => true,

);
