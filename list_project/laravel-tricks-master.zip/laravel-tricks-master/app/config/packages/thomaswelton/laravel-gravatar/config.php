<?php

return array(
    'size' => 100,
    'default' => 'mm'
);
