<?php 

return array(
	'site_title' => ':title | Laravel-Tricks.com',
	'browsing_most_recent_tricks' => 'Browsing Most Recent Laravel Tricks',
	'browsing_most_popular_tricks' => 'Browsing Most Popular Laravel Tricks',
	'browsing_tag' => 'Browsing Tag ":tag"',
	'tag' => 'Tag ":tag"',
	'tags' => 'Tags',
	'category' => 'Category ":category"',
	'categories' => 'Categories',
	'recent' => 'Recent',
	'popular' => 'Popular',
	'most_commented' => 'Most commented',
	'browsing_most_commented_tricks' => 'Browsing Most Commented Laravel Tricks',
	'browsing_category' => 'Browsing Category ":category"',
    
);