<?php 

return array(
	'title' => 'Laravel-Tricks',	
	'link' => 'http://www.laravel-tricks.com',	
	'sub_title' => 'Laravel tricks is a website that aggregates useful tips and tricks for Laravel PHP framework',
	'author' => '
	    <author>
		<name>Maks Surguy</name>
		<uri>http://twitter.com/msurguy</uri>
	    </author>
	    <author>
		<name>Stidges</name>
		<uri>http://twitter.com/stidges</uri>
	    </author>',
);

