<?php 

return array(
	'password_reset' => 'Password Reset',
	'reset_password_here' => 'To reset your password, complete this form: :form_link',
	    
);