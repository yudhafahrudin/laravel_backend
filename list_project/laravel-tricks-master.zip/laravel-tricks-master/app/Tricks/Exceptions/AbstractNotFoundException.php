<?php

namespace Tricks\Exceptions;

use Exception;

abstract class AbstractNotFoundException extends Exception
{

}
