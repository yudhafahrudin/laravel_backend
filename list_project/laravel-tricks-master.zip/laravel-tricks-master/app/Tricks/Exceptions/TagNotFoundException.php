<?php

namespace Tricks\Exceptions;

class TagNotFoundException extends AbstractNotFoundException
{

}
