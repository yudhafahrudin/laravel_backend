<?php

namespace Tricks\Exceptions;

class UserNotFoundException extends AbstractNotFoundException
{

}
