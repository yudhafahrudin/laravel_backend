<?php

namespace Tricks\Exceptions;

use RuntimeException;

class GithubEmailAccessException extends RuntimeException
{

}
