<?php

return array(
	
	// SEO mapping
	'seo_mapping' => array(
		'products' 			=> 'Products',
		'categories'			=> 'Categories',
	),
);