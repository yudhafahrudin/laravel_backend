<?php

return array(
        'api_key'       => '',
        'sender'        => array(
                'name'          => 'Sender Name',
                'address'       => 'sender@address.com',
        ),
);