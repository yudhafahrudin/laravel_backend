<?php

return array(

	'connections' => array(

		'mysql' => array(
			'driver'    => 'mysql',
            'host'      => 'localhost',
            'database'  => 'shop-pagination',
            'username'  => 'root',
            'password'  => 'root',
			'charset'   => 'utf8',
			'collation' => 'utf8_unicode_ci',
			'prefix'    => '',
		)
	)
);
