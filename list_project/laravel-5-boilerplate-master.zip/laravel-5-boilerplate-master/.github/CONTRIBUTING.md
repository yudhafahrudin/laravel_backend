Thank you for wanting to contribute to the project!
================================================
Before you spend time on building something, please share your plans/ideas as an issue. That way we can decide if the idea suits the project.

Please follow this steps when you make a PR:

1. Fork the project ( https://github.com/rappasoft/laravel-5-boilerplate/fork )
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create a new Pull Request
